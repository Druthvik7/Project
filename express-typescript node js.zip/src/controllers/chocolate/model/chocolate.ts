export class Chocolates {
  name!: string;
  amount!: number;
  quantity?: number;
}
