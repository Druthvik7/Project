import { User } from './user';
import { Post } from './post';
import { Comment } from './comment';
import { Student } from '../controllers/studentmanagement/studentsranking/model/student';
import { Subject } from '../controllers/studentmanagement/studentsranking/model/subject';
import { Mark } from '../controllers/studentmanagement/studentsranking/model/mark';
import {Product} from '../controllers/canbrowser/model/product'
import {Resources} from '../controllers/canbrowser/model/resource'

export { User, Post, Comment, Student, Subject, Mark , Product,Resources };
